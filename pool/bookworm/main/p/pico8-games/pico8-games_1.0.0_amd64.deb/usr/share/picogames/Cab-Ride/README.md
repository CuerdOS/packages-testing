# CAB RIDE

Drive a train, forever, through a dreamlike land.

Transport passengers to their destination.

Watch the world go by.

Listen to chilled out chiptune music.

In Cab Ride you can drive thousands of different train routes through rolling hills, winding tunnels and weaving between the tall buildings of vast cities. You can drive the train for as long as you like. When you're ready to end your journey, hold down the left arrow key to announce the last station. Stopping at stations along the way means you can pick up and drop off passengers. Try and stop at the marker at each station for a high rating. Or don't! It's up to you.

Cab Ride is a casual train simulation, not aiming for real world accuracy, but like a real train, it takes a while to brake. If you're overshooting stations, watch for the alert for the next station and reduce the throttle so you're ready to stop.

## Installation

Unzip/extract this zipfile aaaaaand....

### Windows

Double click the Cab Ride icon in Explorer

### Linux

Running
```
$ ./cab-ride 
```
in your terminal from the Cab Ride directory should do the trick

### Mac

Double click the Cab Ride app icon in Finder

## Controls

- X - horn/start/restart the game
- Z/C - open/close doors at station (must have stopped just in front of signal)
- Up - increase braking/decrease throttle
- Down - accelerate/increase throttle
- Left - hold down to announce the last station (will end the current journey)
- Right - hold down to turn Express mode on/off aka Screensaver Mode

Sound can be toggled via the PICO-8 pause menu.

Version history

v1.2

- Fixed - memory leak if you run the game for a *long* time

v1.1

- Added - second track with train
- Added - Weather - different cloud patterns and periods of rain
- More performance fixes 

v1.0.3

- Changed - tweaked station stop ratings - slightly more forgiving and more consistent
- Changed - all green signals when you're in express mode (after first couple of stations)
- Fixed - all passengers would eventually get off if you opened the doors enough times at a single station
- Various performance improvements

v1.0.2

- Added - pause menu sound toggle - deals with no hardware button in mobile view - may fix in a different way in future
- Added - 'very chilled' mode - no goal/help messages, no HUD other than station name messages, just driving trains - good for screenshots or screen savers (even better than what I claimed was a good screen saver mode before)
- Fixed - another way to drive through the last station (activate Express mode after announcing last station)

v1.0.1

- Fixed - crash bug where you could drive out of the last station when in 'Express' mode
- Changed - you now have to hold down the right key for 2 seconds to enable Express mode (announcing the last stop also has a 2 second delay) - this is to prevent ending up in that mode by accident and locking the controls

v1.0

- Initial release

## Credits

Programming/art  - Ben Jones / [@Powersaurus](https://twitter.com/Powersaurus)

Music - Stephen 'rych-t' Jones / [Twitter](https://twitter.com/rych_t) / [Soundcloud](soundcloud.com/floor-machoor)

Based on code from the Pseudo-3D Racer tutorials by Tom Mulgrew/ @Mot [https://www.lexaloffle.com/bbs/?tid=35767 ](https://www.lexaloffle.com/bbs/?tid=35767) licensed under Creative Commons 4 (CC BY 4.0) [https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)

Made using [PICO-8](https://www.lexaloffle.com/pico-8.php)

Desktop release uses [SDL2](https://www.libsdl.org/license.php)
