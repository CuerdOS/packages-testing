#!/bin/bash

# Remove kisak-mesa from each repository line
echo "$USER needs superuser privileges to perform this action."
FILE_PATH="/etc/apt/sources.list.d/kisak_stable.list && rm -rf /usr/share/keyrings/kisak_mesa_stable.asc"

pkexec rm -rf $FILE_PATH

