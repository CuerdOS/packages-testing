#!/bin/bash
# Check if the repositories are already present before adding them
if grep -q " non-free contrib" /etc/apt/sources.list; then
    zenity --info --text="Repositories are already present. No changes made."
else
    # Add 'non-free' and 'contrib' at the end of each repository line
    echo "$USER needs superuser privileges to perform this action."
    pkexec sed -i '/^deb/ s/$/ non-free contrib/' /etc/apt/sources.list
fi

