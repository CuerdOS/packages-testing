#!/bin/bash

# Check if the repositories are already present before adding them
if [ -f "/etc/apt/sources.list.d/kisak_stable.list" ]; then
    zenity --info --text="Repositories are already present. No changes made."
else
    echo "$USER needs superuser privileges to perform this action."
    # Add kisak_stable.list
    FILE_PATH="/etc/apt/sources.list.d/kisak_stable.list"

    FILE_CONTENT="deb [signed-by=/usr/share/keyrings/kisak_mesa_stable.asc] https://ppa.launchpadcontent.net/kisak/turtle/ubuntu jammy main
    deb-src [signed-by=/usr/share/keyrings/kisak_mesa_stable.asc] https://ppa.launchpadcontent.net/kisak/turtle/ubuntu jammy main"
    
    # Copy the keyring file and write content to the file within pkexec
    pkexec bash -c "
    cp '/usr/share/setup-repos/keyrings/kisak_mesa_stable.asc' '/usr/share/keyrings/kisak_mesa_stable.asc'
    echo '$FILE_CONTENT' > $FILE_PATH"
fi

