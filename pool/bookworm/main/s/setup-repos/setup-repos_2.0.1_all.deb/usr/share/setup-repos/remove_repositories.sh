#!/bin/bash

# Remove 'non-free' and 'contrib' from each repository line
echo "$USER needs superuser privileges to perform this action."
pkexec sed -i 's/ non-free contrib//g' /etc/apt/sources.list

