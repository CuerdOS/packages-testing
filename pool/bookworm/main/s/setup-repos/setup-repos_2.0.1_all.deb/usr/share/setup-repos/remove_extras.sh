#!/bin/bash

# Remove cuerdos-extras from each repository line
echo "$USER needs superuser privileges to perform this action."
pkexec rm -rf /etc/apt/sources.list.d/cuerdos_extras.list

