#!/bin/bash

# Check if the repositories are already present before adding them
if [ -f "/etc/apt/sources.list.d/cuerdos_extras.list" ]; then
    zenity --info --text="Repositories are already present. No changes made."
else
    # Add cuerdos-extras at the end of each repository line
    echo "$USER needs superuser privileges to perform this action."
    pkexec sh -c 'echo "deb [trusted=yes] https://cuerdos.fury.site/apt/ /" > /etc/apt/sources.list.d/cuerdos_extras.list'
fi

