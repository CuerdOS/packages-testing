@echo off
hdpmi32
fuel
