from bauh import ROOT_DIR


def get_path(resource_path):
    return ROOT_DIR + '/view/resources/' + resource_path
