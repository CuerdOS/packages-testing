from typing import Optional


class NoInternetException(Exception):
    pass
