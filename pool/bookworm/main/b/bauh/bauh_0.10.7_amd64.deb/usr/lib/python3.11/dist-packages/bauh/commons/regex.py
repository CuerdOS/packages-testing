import re

RE_URL = re.compile(r"^https?://.+$")
