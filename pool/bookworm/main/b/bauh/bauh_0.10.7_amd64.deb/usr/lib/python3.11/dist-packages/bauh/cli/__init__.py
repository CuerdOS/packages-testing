from bauh import __app_name__

__app_name__ = '{}-cli'.format(__app_name__)
