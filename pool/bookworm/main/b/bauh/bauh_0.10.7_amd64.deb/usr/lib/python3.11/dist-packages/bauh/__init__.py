__version__ = '0.10.7'
__app_name__ = 'bauh'

import os
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
